<?php
/**
 * Silence is golden.
 *
 * @package  Iubenda
 */
