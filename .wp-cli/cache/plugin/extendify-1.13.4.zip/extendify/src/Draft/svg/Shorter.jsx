const shorter = (
	<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
		<path d="M4 9H20V11H4V9ZM4 13H14V15H4V13Z" />
	</svg>
);

export default shorter;
