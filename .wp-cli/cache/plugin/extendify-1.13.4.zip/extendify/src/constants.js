export const PATTERNS_HOST = 'https://patterns.extendify.com';
// export const PATTERNS_HOST = 'http://localhost:3000'
export const KB_HOST = 'https://kb.extendify.com';
// export const KB_HOST = 'http://localhost:3000';
export const AI_HOST = 'https://ai.extendify.com';
// export const AI_HOST = 'http://localhost:3000';
export const INSIGHTS_HOST = 'https://insights.extendify.com';
// export const INSIGHTS_HOST = 'http://localhost:3000';
