README 
Geom Release 1.000
========================

Thank you for your interest in the Geom font.
We hope you find it useful!

Geom provides glyphs for Greek and Latin characters.
Please read the online documentation to see what ranges are supported. 

Geom is released under the SIL Open Font License.
	
See the OFL for details of the SIL Open Font License.


TIPS
====

As this font is distributed at no cost, we are unable to provide a 
commercial level of personal technical support. The font has, however, 
been through some testing on various platforms to be sure it works in most
situations. In particular, it has been tested and shown to work on 
Windows 10.


INSTALLATION AND CONFIGURATION
==============================
If you are not sure how to install the fonts, please copy the file following the path below:
C:\Windows\Fonts


CONTACT
========
For more information please send an email to thanospoulakidas@gmail.com


